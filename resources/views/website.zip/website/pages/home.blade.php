@extends('website.master')
@section('title')
Jafree Ecommerce - Homepage
@endsection
@section('content')
@include('website.includes.slider')



@include('website.pages.body')
@endsection