<!DOCTYPE html>
<html lang="en" dir="ltr">

    <!-- header start -->
@include('website.includes.header')	
   <!-- header end -->

<body><!-- quickview-modal -->
    <div id="quickview-modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-xl">
            <div class="modal-content"></div>
        </div>
    </div><!-- quickview-modal / end -->
   
    <div class="site"><!-- mobile site__header -->
      
           <!-- topnavbars start  -->

        @include('website.includes.topnavbar')	
              
         <!-- topnavbars ends -->

        <div class="site__body">
            <!-- .block-slideshow start-->
             @yield('content')
        <!-- @include('website.includes.slider')	 -->

             <!-- block slider end -->
    
             <!-- @include('website.pages.body')	 -->
        </div><!-- site__body / end -->
        <!-- site__footer -->
         <!-- footer -->
         @include('website.includes.footer')	
        <!-- //footer -->
       
       
    </div><!-- site / end -->
</body>

</html>